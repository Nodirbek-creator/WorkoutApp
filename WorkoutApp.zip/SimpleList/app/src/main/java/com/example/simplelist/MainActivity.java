package com.example.simplelist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycleView);
        List<Category> list = new ArrayList<Category>();
        list.add(new Category("Pull up", "Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.pulling_up));
        list.add(new Category("Punching","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.boxing_glove));
        list.add(new Category("Arms","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.arm));
        list.add(new Category("Legs","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.leg));
        list.add(new Category("Six pack","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.six_pack));
        list.add(new Category("Back muscles","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.back));
        list.add(new Category("Running","Lorem ipsum dolor sit amet. \nDolor sit amet ipsum lorem.",R.drawable.running));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Adaptor(getApplicationContext(),list));
    }
}