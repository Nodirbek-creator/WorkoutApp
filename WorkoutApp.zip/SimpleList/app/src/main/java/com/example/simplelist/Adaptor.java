package com.example.simplelist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adaptor extends RecyclerView.Adapter<CategoryHolder> {

    Context context;
    List<Category> categoryList;

    public Adaptor(Context context, List<Category> categoryList) {
        this.context = context;
        this.categoryList = categoryList;
    }

    @NonNull
    @Override
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new CategoryHolder(LayoutInflater.from(context).inflate(R.layout.category_view,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder categoryHolder, int position) {
        categoryHolder.name.setText(categoryList.get(position).name);
        categoryHolder.description.setText(categoryList.get(position).description);
        categoryHolder.image.setImageResource(categoryList.get(position).image);
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }
}
